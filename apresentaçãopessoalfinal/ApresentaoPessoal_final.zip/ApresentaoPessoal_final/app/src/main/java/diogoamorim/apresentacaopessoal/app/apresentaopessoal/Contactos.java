package diogoamorim.apresentacaopessoal.app.apresentaopessoal;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


/**
 * A simple {@link Fragment} subclass.
 */
public class Contactos extends Fragment {


    public Contactos() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_contactos, container, false);
    }


    public void onClick(View v) {

        switch (v.getId()) {


            case R.id.button:

                sendMail();
                break;

            case R.id.button2:


                break;
            default:
                break;

        }

    }
    private void sendMail() {
        // Define o destinatário (meu email)
        String listaDestinos = "diogomaaa98@gmail.com";
        String[] destinatarios = listaDestinos.split(",");

        // Getter do texto das caixas de texto
        String assunto = "";
        String mensagem = "";

        // Envia os dados para outro processo
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_EMAIL, destinatarios);
        intent.putExtra(Intent.EXTRA_SUBJECT, assunto);
        intent.putExtra(Intent.EXTRA_TEXT, mensagem);

        // Pergunta para escolher o serviço e depois envia os dados do Intent
        // para a aplicação preenchendo assim o formulario do email.
        intent.setType("message/rfc822");
        startActivity(Intent.createChooser(intent, "ESCREVE"));
    }
}
