package diogoamorim.apresentacaopessoal.app.apresentaopessoal;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


/**
 * A simple {@link Fragment} subclass.
 */
public class SobreMim extends Fragment implements View.OnClickListener {


    public SobreMim() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_sobre_mim, container, false);

        Button b = (Button) v.findViewById(R.id.HOBBIES);
        b.setOnClickListener(this);

        Button b2 = (Button) v.findViewById(R.id.ESTUDOS);
        b2.setOnClickListener(this);


        return v;
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.HOBBIES:

                Hobbies hobbiesfragment = new Hobbies();
                android.support.v4.app.FragmentManager manager = getActivity().getSupportFragmentManager();
                manager.beginTransaction()
                        .replace(R.id.relative_layout_para_o_fragment,
                                hobbiesfragment, hobbiesfragment.getTag()
                        ).commit();

                break;

            case R.id.ESTUDOS:

                Habilitacoes habilitacoesfragment = new Habilitacoes();
                android.support.v4.app.FragmentManager manager2 = getActivity().getSupportFragmentManager();
                manager2.beginTransaction()
                        .replace(R.id.relative_layout_para_o_fragment,
                                habilitacoesfragment, habilitacoesfragment.getTag()
                        ).commit();

                break;

        }

    }
}
