package diogoamorim.apresentacaopessoal.app.apresentaopessoal;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


/**
 * A simple {@link Fragment} subclass.
 */
public class Habilitacoes extends Fragment implements View.OnClickListener {


    public Habilitacoes() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_habilitacoes, container, false);

        Button b = (Button) v.findViewById(R.id.sobre);
        b.setOnClickListener(this);

        return v;
    }

    @Override
    public void onClick(View v) {

        SobreMim sobreMimfragment = new SobreMim();
        android.support.v4.app.FragmentManager manager = getActivity().getSupportFragmentManager();
        manager.beginTransaction()
                .replace(R.id.relative_layout_para_o_fragment,
                        sobreMimfragment, sobreMimfragment.getTag()
                ).commit();

    }
}
