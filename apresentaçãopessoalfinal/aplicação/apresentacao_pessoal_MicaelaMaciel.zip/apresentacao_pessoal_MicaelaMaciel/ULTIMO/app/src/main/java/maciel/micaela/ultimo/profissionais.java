package maciel.micaela.ultimo;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class profissionais extends AppCompatActivity  {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profissionais);

        Button meu_botao=(Button) this.findViewById(R.id.button_samsys);
        meu_botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse("http://www.samsys.pt/");
                Intent intent = new Intent(Intent.ACTION_VIEW,uri);
                startActivity(intent);
            }
        });

        Button meu_botao2=(Button) this.findViewById(R.id.button_laland);
        meu_botao2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse("https://www.facebook.com/lalalandstudios/");
                Intent intent = new Intent(Intent.ACTION_VIEW,uri);
                startActivity(intent);}});

        Button meu_botao3=(Button) this.findViewById(R.id.button_myguest);
        meu_botao3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse("https://www.facebook.com/mgreport/");
                Intent intent = new Intent(Intent.ACTION_VIEW,uri);
                startActivity(intent);}});


    }

}


